let studentCount = 0;

function enroll(courseId) {
  const name = document.getElementById(`name_${courseId}`).value;
  const email = document.getElementById(`email_${courseId}`).value;
  const classTimings = document.getElementById(`classTimings_${courseId}`).value;
  const paymentMethod = document.getElementById(`paymentMethod_${courseId}`).value;

  if (name !== '' && email !== '') {
    studentCount++;
    document.getElementById('studentCount').textContent = studentCount;

    const enrollmentName = document.getElementById(`enrollmentName_${courseId}`);
    const enrollmentEmail = document.getElementById(`enrollmentEmail_${courseId}`);
    const enrollmentClassTimings = document.getElementById(`enrollmentClassTimings_${courseId}`);
    const enrollmentPaymentMethod = document.getElementById(`enrollmentPaymentMethod_${courseId}`);

    enrollmentName.textContent = name;
    enrollmentEmail.textContent = email;
    enrollmentClassTimings.textContent = classTimings;
    enrollmentPaymentMethod.textContent = paymentMethod;

    const enrollButton = document.getElementById(`enrollButton_${courseId}`);
    const unenrollButton = document.getElementById(`unenrollButton_${courseId}`);
    const enrollmentDetails = document.getElementById(`enrollmentDetails_${courseId}`);

    enrollButton.style.display = 'none';
    unenrollButton.style.display = 'inline';
    enrollmentDetails.style.display = 'block';

    alert(`Enrollment successful! Welcome, ${name}!`);
  } else {
    alert('Please fill in all fields.');
  }
}

function toggleUnenrollment(courseId) {
  const enrollButton = document.getElementById(`enrollButton_${courseId}`);
  const unenrollButton = document.getElementById(`unenrollButton_${courseId}`);
  const enrollmentDetails = document.getElementById(`enrollmentDetails_${courseId}`);

  enrollButton.style.display = 'inline';
  unenrollButton.style.display = 'none';
  enrollmentDetails.style.display = 'none';

  alert(`You have unenrolled from ${courseId}.`);
}

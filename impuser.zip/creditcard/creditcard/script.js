const form = document.getElementById('checkoutForm');
const result = document.getElementById('result');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  const fullName = document.getElementById('fullName').value;
  const email = document.getElementById('email').value;
  const address = document.getElementById('address').value;
  const cardNumber = document.getElementById('cardNumber').value;
  const expiryDate = document.getElementById('expiryDate').value;
  const cvv = document.getElementById('cvv').value;
  
  if (validateUserDetails(fullName, email, address) && 
      validateCard(cardNumber) && 
      validateExpiry(expiryDate) && 
      validateCVV(cvv)) {
    result.innerHTML = 'Form submission successful.';
    // Here you can proceed with submitting the form data or any other action
  } else {
    result.innerHTML = 'Invalid form data. Please check and try again.';
  }
});

function validateUserDetails(fullName, email, address) {
  // Validate full name
  const nameRegex = /^[a-zA-Z\s]+$/;
  if (!nameRegex.test(fullName)) {
    return false;
  }

  // Validate email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return false;
  }

  // Validate address
  if (address.trim() === '') {
    return false;
  }

  return true;
}

function validateCard(cardNumber) {
  // You can implement credit card number validation logic here
  return cardNumber.length === 19; // Dummy validation for demonstration
}

function validateExpiry(expiryDate) {
  // You can implement expiry date validation logic here
  return expiryDate.length === 5; // Dummy validation for demonstration
}

function validateCVV(cvv) {
  // You can implement CVV validation logic here
  return cvv.length === 3; // Dummy validation for demonstration
}
